export const APP_NAME = "Mobile Store App";
export const hostUrl = 'http://localhost:8080/';
export const authToken = 'mobile-auth-token';